
  # AMTS App Design

  This is a code bundle for AMTS App Design. The original project is available at https://www.figma.com/design/pFdtOl4d2Q9YE1vsYSKfaA/AMTS-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  